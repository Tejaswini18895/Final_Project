--------------------------------------------------------------------
Author Name : Tejaswini Gaddam
Programming Assignment 3
--------------------------------------------------------------------

Files Included: 
1.3d.html
2.3d3d.html
3.asgnt3.html
4.box.html
5.box3d.html
6.slide.html
7.slide3d.html
8.style.css

-- asgnt3.html is the home page which contains buttons on clikcing directs to approprite pages.

-- On clicking "House" it goes to 3d.html page which shows the front side and top view of the house, there is a link on the page for viewing 3d model of the house.

-- On clicking "slidingbox.html" it goes to slide.html page which shows the front side and top view of the image, there is a link on the page for viewing 3d model of the sliding box.

--On clicking "Pile of boxes" it goes to box.html page which shows the front side and top view of the boxes, there is a link on the page for viewing 3d model of the boxes.

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
  